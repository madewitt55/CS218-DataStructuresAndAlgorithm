### linked_list_stack || 1/22/25
- C++ class to create a linked list based stack
- LinkedStack is a template class, capable of holding any data type
- StudentInfo struct is used to test, holding id, name, phone number, and address